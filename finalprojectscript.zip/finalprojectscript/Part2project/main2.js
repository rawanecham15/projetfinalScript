document.addEventListener('DOMContentLoaded', function() {
    const contactBtn = document.getElementById('contactBtn');
    const contactForm = document.getElementById('contactForm');

    contactBtn.addEventListener('click', function() {
        contactForm.style.display = 'block';
    });
});
videoBtn.addEventListener('click', function() {
    window.location.href =('/Part2project/yt5s.io-4K Forest - Cinematic Forest - 4K Nature Video Ultra HD.mp4');
});

photoBtn.addEventListener('click', function() {
    window.location.href =('/Part2project/p.jpg');
});

cvBtn.addEventListener('click', function() {
    window.location.href = '/Part2project/Rawane cv .pdf';
});
